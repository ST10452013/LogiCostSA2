package com.example.logicostapp3

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import java.util.Locale

data class MarketplaceListing(
    val id: Int,
    val title: String,
    val company: String,
    val description: String,
    val type: String,
    val city: String,
    val province: String,
    val price: Double
)

class MarketplaceFragment : Fragment() {

    private lateinit var listingsLayout: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var typeSpinner: Spinner

    private val listings = mutableListOf(
        MarketplaceListing(
            1, "Bulk Packaging Materials", "Cape Supply Co.",
            "Cardboard boxes, wrapping materials and packaging supplies.",
            "Product", "Johannesburg", "Gauteng", 1250.00
        ),
        MarketplaceListing(
            2, "Local Delivery Services", "Swift Logistics",
            "Reliable local deliveries for small and medium-sized businesses.",
            "Delivery", "Pretoria", "Gauteng", 350.00
        ),
        MarketplaceListing(
            3, "Warehouse Storage", "Prime Warehouse Solutions",
            "Affordable storage and inventory handling services.",
            "Service", "Durban", "KwaZulu-Natal", 2000.00
        ),
        MarketplaceListing(
            4, "Pallets and Crates", "Industrial Traders",
            "Wooden pallets and reusable transport crates available in bulk.",
            "Product", "Cape Town", "Western Cape", 850.00
        )
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(
            R.layout.fragment_marketplace,
            container,
            false
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        listingsLayout = view.findViewById(R.id.layoutMarketplaceListings)
        searchInput = view.findViewById(R.id.etMarketplaceSearch)
        typeSpinner = view.findViewById(R.id.spinnerListingType)

        view.findViewById<Button>(R.id.btnPublishListing)
            .setOnClickListener { showPublishDialog() }

        searchInput.doAfterTextChanged {
            renderListings()
        }

        typeSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    renderListings()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        renderListings()
    }

    private fun renderListings() {
        listingsLayout.removeAllViews()

        val query = searchInput.text.toString().trim().lowercase(Locale.ROOT)
        val selectedType = typeSpinner.selectedItem?.toString() ?: "All types"

        val filtered = listings.filter { listing ->
            val matchesSearch =
                listing.title.lowercase(Locale.ROOT).contains(query) ||
                        listing.company.lowercase(Locale.ROOT).contains(query) ||
                        listing.description.lowercase(Locale.ROOT).contains(query) ||
                        listing.city.lowercase(Locale.ROOT).contains(query) ||
                        listing.province.lowercase(Locale.ROOT).contains(query)

            val matchesType =
                selectedType == "All types" || listing.type == selectedType

            matchesSearch && matchesType
        }

        if (filtered.isEmpty()) {
            val emptyText = TextView(requireContext()).apply {
                text = "No listings found. Try another search."
                textSize = 14f
                setTextColor(0xFF687386.toInt())
                setPadding(0, 16, 0, 16)
            }
            listingsLayout.addView(emptyText)
            return
        }

        filtered.forEach { listing ->
            val card = layoutInflater.inflate(
                R.layout.item_marketplace_listing,
                listingsLayout,
                false
            )

            card.findViewById<TextView>(R.id.tvListingType).text =
                listing.type.uppercase(Locale.ROOT)

            card.findViewById<TextView>(R.id.tvListingTitle).text =
                listing.title

            card.findViewById<TextView>(R.id.tvListingCompany).text =
                listing.company

            card.findViewById<TextView>(R.id.tvListingLocation).text =
                "${listing.city}, ${listing.province}"

            card.findViewById<TextView>(R.id.tvListingDescription).text =
                listing.description

            card.findViewById<TextView>(R.id.tvListingPrice).text =
                "From R ${"%,.2f".format(Locale.US, listing.price)}"

            card.findViewById<Button>(R.id.btnRequestQuote)
                .setOnClickListener {
                    showQuoteDialog(listing)
                }

            listingsLayout.addView(card)
        }
    }

    private fun showQuoteDialog(listing: MarketplaceListing) {
        val input = EditText(requireContext()).apply {
            hint = "Describe what you need"
            minLines = 3
            gravity = android.view.Gravity.TOP
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Request a quote")
            .setMessage("Listing: ${listing.title}")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Submit") { _, _ ->
                if (input.text.toString().trim().isEmpty()) {
                    Toast.makeText(
                        requireContext(),
                        "Please describe your requirements.",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        requireContext(),
                        "API connection still required to submit this request.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            .show()
    }

    private fun showPublishDialog() {
        val form = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 0, 24, 0)
        }

        fun addField(hintText: String): EditText {
            val field = EditText(requireContext()).apply {
                hint = hintText
                isSingleLine = hintText != "Description"
            }
            form.addView(field)
            return field
        }

        val title = addField("Listing title")
        val description = addField("Description")
        val company = addField("Business name")

        val type = Spinner(requireContext()).apply {
            adapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Product", "Service", "Delivery")
            )
        }
        form.addView(type)

        val city = addField("City")
        val province = addField("Province")
        val price = addField("Price in rand")
        price.inputType =
            android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL

        AlertDialog.Builder(requireContext())
            .setTitle("Publish a listing")
            .setView(ScrollView(requireContext()).apply { addView(form) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Publish") { _, _ ->
                val amount = price.text.toString().toDoubleOrNull()

                if (
                    title.text.isBlank() ||
                    description.text.isBlank() ||
                    company.text.isBlank() ||
                    city.text.isBlank() ||
                    province.text.isBlank() ||
                    amount == null || amount < 0
                ) {
                    Toast.makeText(
                        requireContext(),
                        "Please complete all fields with a valid price.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setPositiveButton
                }

                listings.add(
                    MarketplaceListing(
                        id = (listings.maxOfOrNull { it.id } ?: 0) + 1,
                        title = title.text.toString().trim(),
                        company = company.text.toString().trim(),
                        description = description.text.toString().trim(),
                        type = type.selectedItem.toString(),
                        city = city.text.toString().trim(),
                        province = province.text.toString().trim(),
                        price = amount
                    )
                )

                renderListings()

                Toast.makeText(
                    requireContext(),
                    "Demo listing added. It has not been saved to the server.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .show()
    }
}
